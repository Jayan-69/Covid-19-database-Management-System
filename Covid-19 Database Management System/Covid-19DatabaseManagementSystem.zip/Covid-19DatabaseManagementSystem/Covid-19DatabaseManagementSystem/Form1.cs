﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Covid_19DatabaseManagementSystem
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //Check the username & password
            if (txtUser.Text == "Sathya" && txtPassword.Text == "1234")
            {
                //Display welcome message
                MessageBox.Show("Welcome" + txtUser.Text + "!", "Login Form", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Main_Menu newmain = new Main_Menu();
                this.Hide();
                newmain.Show();
            }

            else

            {
                //Display error message
                MessageBox.Show("Invalid Username or Password !", "Login Form", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //Select the UID
                txtUser.Focus();
                txtUser.SelectAll();
                //Clear password
                txtPassword.Clear();
            }

           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
