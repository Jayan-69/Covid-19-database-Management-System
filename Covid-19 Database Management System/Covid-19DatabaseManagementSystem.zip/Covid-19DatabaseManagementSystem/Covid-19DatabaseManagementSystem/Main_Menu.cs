﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Covid_19DatabaseManagementSystem
{
    public partial class Main_Menu : Form
    {
        public Main_Menu()
        {
            InitializeComponent();
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            Ptn_Reg newreg = new Ptn_Reg();
            this.Hide();
            newreg.Show();
        }

        private void btnPCR_Click(object sender, EventArgs e)
        {
            Pcr_Info newpcr = new Pcr_Info();
            this.Hide();
            newpcr.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
