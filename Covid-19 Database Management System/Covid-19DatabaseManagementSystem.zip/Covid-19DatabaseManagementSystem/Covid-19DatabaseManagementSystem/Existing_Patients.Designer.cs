﻿namespace Covid_19DatabaseManagementSystem
{
    partial class Existing_Patients
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnCle = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnDVG = new System.Windows.Forms.Button();
            this.dvg = new System.Windows.Forms.DataGridView();
            this.lblPID = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblstmt = new System.Windows.Forms.Label();
            this.txtPID = new System.Windows.Forms.TextBox();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.txtStmt = new System.Windows.Forms.TextBox();
            this.btnDel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dvg)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Blue;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(41, 374);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 0;
            this.btnSearch.Text = "Search ";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnCle
            // 
            this.btnCle.BackColor = System.Drawing.Color.Blue;
            this.btnCle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCle.Location = new System.Drawing.Point(187, 374);
            this.btnCle.Name = "btnCle";
            this.btnCle.Size = new System.Drawing.Size(75, 23);
            this.btnCle.TabIndex = 1;
            this.btnCle.Text = "Clear";
            this.btnCle.UseVisualStyleBackColor = false;
            this.btnCle.Click += new System.EventHandler(this.btnCle_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Blue;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(471, 374);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(618, 374);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnDVG
            // 
            this.btnDVG.BackColor = System.Drawing.Color.Lime;
            this.btnDVG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDVG.Location = new System.Drawing.Point(423, 280);
            this.btnDVG.Name = "btnDVG";
            this.btnDVG.Size = new System.Drawing.Size(270, 23);
            this.btnDVG.TabIndex = 4;
            this.btnDVG.Text = "Show Data ";
            this.btnDVG.UseVisualStyleBackColor = false;
            this.btnDVG.Click += new System.EventHandler(this.btnDVG_Click);
            // 
            // dvg
            // 
            this.dvg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvg.Location = new System.Drawing.Point(423, 27);
            this.dvg.Name = "dvg";
            this.dvg.Size = new System.Drawing.Size(270, 184);
            this.dvg.TabIndex = 5;
            // 
            // lblPID
            // 
            this.lblPID.AutoSize = true;
            this.lblPID.BackColor = System.Drawing.Color.Gold;
            this.lblPID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPID.Location = new System.Drawing.Point(81, 27);
            this.lblPID.Name = "lblPID";
            this.lblPID.Size = new System.Drawing.Size(70, 15);
            this.lblPID.TabIndex = 6;
            this.lblPID.Text = "Patient ID";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Gold;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(81, 144);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(94, 15);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "Patient Name";
            // 
            // lblstmt
            // 
            this.lblstmt.AutoSize = true;
            this.lblstmt.BackColor = System.Drawing.Color.Gold;
            this.lblstmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstmt.Location = new System.Drawing.Point(81, 260);
            this.lblstmt.Name = "lblstmt";
            this.lblstmt.Size = new System.Drawing.Size(72, 15);
            this.lblstmt.TabIndex = 9;
            this.lblstmt.Text = "Statement";
            // 
            // txtPID
            // 
            this.txtPID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPID.Location = new System.Drawing.Point(221, 24);
            this.txtPID.Name = "txtPID";
            this.txtPID.Size = new System.Drawing.Size(165, 21);
            this.txtPID.TabIndex = 10;
            // 
            // txtPName
            // 
            this.txtPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPName.Location = new System.Drawing.Point(221, 141);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(165, 21);
            this.txtPName.TabIndex = 11;
            // 
            // txtStmt
            // 
            this.txtStmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStmt.Location = new System.Drawing.Point(221, 257);
            this.txtStmt.Name = "txtStmt";
            this.txtStmt.Size = new System.Drawing.Size(165, 21);
            this.txtStmt.TabIndex = 13;
            // 
            // btnDel
            // 
            this.btnDel.BackColor = System.Drawing.Color.Blue;
            this.btnDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDel.Location = new System.Drawing.Point(328, 374);
            this.btnDel.Name = "btnDel";
            this.btnDel.Size = new System.Drawing.Size(75, 23);
            this.btnDel.TabIndex = 14;
            this.btnDel.Text = "Delete";
            this.btnDel.UseVisualStyleBackColor = false;
            this.btnDel.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // Existing_Patients
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Covid_19DatabaseManagementSystem.Properties.Resources.aed55c1f1f133964094cb07e4f391b7e;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(738, 439);
            this.Controls.Add(this.btnDel);
            this.Controls.Add(this.txtStmt);
            this.Controls.Add(this.txtPName);
            this.Controls.Add(this.txtPID);
            this.Controls.Add(this.lblstmt);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblPID);
            this.Controls.Add(this.dvg);
            this.Controls.Add(this.btnDVG);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnCle);
            this.Controls.Add(this.btnSearch);
            this.Name = "Existing_Patients";
            this.Text = "Existing Patients";
            this.Load += new System.EventHandler(this.Existing_Patients_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dvg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnCle;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnDVG;
        private System.Windows.Forms.DataGridView dvg;
        private System.Windows.Forms.Label lblPID;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblstmt;
        private System.Windows.Forms.TextBox txtPID;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.TextBox txtStmt;
        private System.Windows.Forms.Button btnDel;
    }
}