﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Covid_19DatabaseManagementSystem
{
    public partial class Pcr_Info : Form
    {
        public Pcr_Info()
        {
            InitializeComponent();
        }

        private void btnRptdetls_Click(object sender, EventArgs e)
        {
            Report_Details newrepdetails = new Report_Details();
            this.Hide();
            newrepdetails.Show();
        }

        private void btnExist_Click(object sender, EventArgs e)
        {
            Existing_Patients newexist = new Existing_Patients();
            this.Hide();
            newexist.Show();
        }

        private void btnHos_Click(object sender, EventArgs e)
        {
            Send_Hospital newreg = new Send_Hospital();
            this.Hide();
            newreg.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Main_Menu newmain = new Main_Menu();
            this.Hide();
            newmain.Show();
        }
    }
}
