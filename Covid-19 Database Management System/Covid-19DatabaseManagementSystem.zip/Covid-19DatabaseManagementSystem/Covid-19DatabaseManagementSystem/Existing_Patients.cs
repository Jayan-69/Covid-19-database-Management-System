﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Covid_19DatabaseManagementSystem
{
    public partial class Existing_Patients : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Covid19;Integrated Security=True");

        SqlDataAdapter adapter = new SqlDataAdapter();
        BindingSource bs = new BindingSource();
        SqlDataReader reader;

        public Existing_Patients()
        {
            InitializeComponent();
        }

        private void Existing_Patients_Load(object sender, EventArgs e)
        {

        }

        private void btnDVG_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                adapter.SelectCommand = new SqlCommand("SELECT * FROM PCR_Report", con);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                bs.Clear();
                adapter.Fill(ds);
                dvg.DataSource = ds.Tables[0];

                bs.DataSource = ds.Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("There is an error occured with : " + ex);
            }
            finally
            {
                con.Close();
            }
        }
        public void position()
        {
            dvg.Rows[bs.Position].Selected = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                String pid = txtPID.Text;
                con.Open();
                String stmt = "SELECT * FROM PCR_Report WHERE PId='" + pid + "'";
                SqlCommand cmd = new SqlCommand(stmt, con);
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    txtPID.Text = reader[0].ToString();
                    txtPName.Text = reader[1].ToString();
                    txtStmt.Text = reader[2].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Pcr_Info newpcr = new Pcr_Info();
            this.Hide();
            newpcr.Show();
        }

        private void btnCle_Click(object sender, EventArgs e)
        {
            txtPID.Clear();
            txtPName.Clear();
            txtStmt.Clear();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                String stmt = "DELETE PCR_Report WHERE PId = '" + txtPID.Text + "'";
                SqlCommand cmd = new SqlCommand(stmt, con);
                int r = cmd.ExecuteNonQuery();

                if (r > 0)
                    MessageBox.Show("Patient details had been Deleted Successfully.");
                else
                    MessageBox.Show("Patient details had not been Deleted Successfully......!!!!!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An Error occurd With : " + ex);

            }
            finally
            {
                con.Close();
            }

        }
    }
}
      
