﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Covid_19DatabaseManagementSystem
{
    public partial class Report_Details : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Covid19;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlDataReader reader;
        SqlCommand sqlcmd;
        public Report_Details()
        {
            InitializeComponent();
        }
        //Create the Record Operation Method
        private void oprRec(string qry)
        {
            //Set the SQL Statement
            sqlcmd = new SqlCommand(qry, con);
            //Update Database
            sqlcmd.ExecuteNonQuery();
        }

        private void Report_Details_Load(object sender, EventArgs e)
        {

        }

        private void btnSaveRec_Click(object sender, EventArgs e)
        {
            try
            {
                adapter.InsertCommand = new SqlCommand("INSERT INTO PCR_Report VALUES(@pid,@pname,@rptstmt)", con);
                adapter.InsertCommand.Parameters.Add("@pid", SqlDbType.VarChar).Value = txtID.Text;
                adapter.InsertCommand.Parameters.Add("@pname", SqlDbType.VarChar).Value = txtPName.Text;
                adapter.InsertCommand.Parameters.Add("@rptstmt", SqlDbType.VarChar).Value = txtStmt.Text;



                con.Open();
                int p = adapter.InsertCommand.ExecuteNonQuery();


                if (p > 0)
                    MessageBox.Show("Patient added to the database");
                else
                    MessageBox.Show("Patient not added please Check the connection");
            }
            catch (Exception ex)
            {
                MessageBox.Show("You have an error with:  " + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnclearRec_Click(object sender, EventArgs e)
        {
            txtID.Clear();                                 
            txtStmt.Clear();
            txtPName.Clear();
        }

        private void btnExitFrm_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBackfrm_Click(object sender, EventArgs e)
        {
            Pcr_Info newpcr = new Pcr_Info();
            this.Hide();
            newpcr.Show();
        }
    }
}
