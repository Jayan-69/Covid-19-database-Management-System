﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Covid_19DatabaseManagementSystem
{
    public partial class Send_Hospital : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Covid19;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlDataReader reader;
        BindingSource bs = new BindingSource();
        SqlCommand sqlcmd;
        public Send_Hospital()
        {
            InitializeComponent();
        }
        //Create the Record Operation Method
        private void oprRec(string qry)
        {
            //Set the SQL Statement
            sqlcmd = new SqlCommand(qry, con);
            //Update Database
            sqlcmd.ExecuteNonQuery();
        }
        private void Send_Hospital_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                adapter.InsertCommand = new SqlCommand("INSERT INTO HsptlReg VALUES(@pid,@pname,@hsptl,@wdno,@BdNo)", con);
                adapter.InsertCommand.Parameters.Add("@pid", SqlDbType.VarChar).Value = txtPID.Text;
                adapter.InsertCommand.Parameters.Add("@pname", SqlDbType.VarChar).Value = txtPName.Text;
                adapter.InsertCommand.Parameters.Add("@hsptl", SqlDbType.VarChar).Value = txtHsptl.Text;
                adapter.InsertCommand.Parameters.Add("@wdno", SqlDbType.VarChar).Value = (txtWdNo.Text);
                adapter.InsertCommand.Parameters.Add("@BdNo", SqlDbType.Int).Value = int.Parse(txtBdNo.Text);



                con.Open(); 
                int h = adapter.InsertCommand.ExecuteNonQuery();


                if (h > 0)
                    MessageBox.Show("Patient added to the database");
                else
                    MessageBox.Show("Patient not added please Check the connection");
            }
            catch (Exception ex)
            {
                MessageBox.Show("You have an error with:  " + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPName.Clear();
            txtPID.Clear();
            txtHsptl.Clear();
            txtWdNo.Clear();
            txtBdNo.Clear();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Pcr_Info newpcr = new Pcr_Info();
            this.Hide();
            newpcr.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDVG_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                adapter.SelectCommand = new SqlCommand("SELECT * FROM HsptlReg", con);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                bs.Clear();
                adapter.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];

                bs.DataSource = ds.Tables[0];
            }
            catch (SqlException ex)
            {
                MessageBox.Show("There is an error occured with : " + ex);
            }
            finally
            {
                con.Close();
            }
        }
        public void position()
        {
            dataGridView1.Rows[bs.Position].Selected = true;
        }
    }
}  

