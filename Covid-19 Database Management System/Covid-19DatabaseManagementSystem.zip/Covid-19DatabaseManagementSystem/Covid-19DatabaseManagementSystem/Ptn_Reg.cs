﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Covid_19DatabaseManagementSystem
{
    public partial class Ptn_Reg : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-EHGU5T7\SQLEXPRESS;Initial Catalog=Covid19;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlDataReader reader;
        SqlCommand sqlcmd;
       

        public Ptn_Reg()
        {
            InitializeComponent();
        }

        //Create the Record Operation Method
        private void oprRec(string qry)
        {
            //Set the SQL Statement
            sqlcmd = new SqlCommand(qry, con);
            //Update Database
            sqlcmd.ExecuteNonQuery();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            Main_Menu newmain = new Main_Menu();
            this.Hide();
            newmain.Show();
        }

        private void btnCle_Click(object sender, EventArgs e)
        {
            txtPID.Clear();
            txtFName.Clear();
            txtLName.Clear();
            txtAddress.Clear();
            txtAge.Clear();
            txtTelNo.Clear();
            txtGen.Clear();
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {

            try
            {
                adapter.InsertCommand = new SqlCommand("INSERT INTO AddPatient VALUES(@pid,@fname,@lname,@address,@Age,@gender,@TelNo)", con);
                adapter.InsertCommand.Parameters.Add("@pid", SqlDbType.VarChar).Value = txtPID.Text;
                adapter.InsertCommand.Parameters.Add("@fname", SqlDbType.VarChar).Value = txtFName.Text;
                adapter.InsertCommand.Parameters.Add("@lname", SqlDbType.VarChar).Value = txtLName.Text;
                adapter.InsertCommand.Parameters.Add("@address", SqlDbType.VarChar).Value = txtAddress.Text;
                adapter.InsertCommand.Parameters.Add("@Age", SqlDbType.Int).Value = int.Parse(txtAge.Text);
                adapter.InsertCommand.Parameters.Add("@gender",SqlDbType.VarChar).Value = txtGen.Text;
                adapter.InsertCommand.Parameters.Add("@TelNo", SqlDbType.Int).Value =int.Parse (txtTelNo.Text);


                con.Open();
                int p = adapter.InsertCommand.ExecuteNonQuery();


                if (p> 0)
                    MessageBox.Show("Patient added to the database");
                else
                    MessageBox.Show("Patient not added please Check the connection");
            }
            catch (Exception ex)
            {
                MessageBox.Show("You have an error with:  " + ex);
            }
            finally
            {
                con.Close();
            }
        }

        private void Ptn_Reg_Load(object sender, EventArgs e)
        {

        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }
    }
 }


