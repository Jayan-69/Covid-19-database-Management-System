﻿namespace Covid_19DatabaseManagementSystem
{
    partial class Report_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSaveRec = new System.Windows.Forms.Button();
            this.btnclearRec = new System.Windows.Forms.Button();
            this.btnBackfrm = new System.Windows.Forms.Button();
            this.btnExitFrm = new System.Windows.Forms.Button();
            this.lblID = new System.Windows.Forms.Label();
            this.lblPName = new System.Windows.Forms.Label();
            this.lblSttmnt = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.txtStmt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSaveRec
            // 
            this.btnSaveRec.BackColor = System.Drawing.Color.Blue;
            this.btnSaveRec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveRec.Location = new System.Drawing.Point(12, 263);
            this.btnSaveRec.Name = "btnSaveRec";
            this.btnSaveRec.Size = new System.Drawing.Size(75, 23);
            this.btnSaveRec.TabIndex = 0;
            this.btnSaveRec.Text = "Save";
            this.btnSaveRec.UseVisualStyleBackColor = false;
            this.btnSaveRec.Click += new System.EventHandler(this.btnSaveRec_Click);
            // 
            // btnclearRec
            // 
            this.btnclearRec.BackColor = System.Drawing.Color.Blue;
            this.btnclearRec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclearRec.Location = new System.Drawing.Point(122, 263);
            this.btnclearRec.Name = "btnclearRec";
            this.btnclearRec.Size = new System.Drawing.Size(75, 23);
            this.btnclearRec.TabIndex = 1;
            this.btnclearRec.Text = "Clear";
            this.btnclearRec.UseVisualStyleBackColor = false;
            this.btnclearRec.Click += new System.EventHandler(this.btnclearRec_Click);
            // 
            // btnBackfrm
            // 
            this.btnBackfrm.BackColor = System.Drawing.Color.Blue;
            this.btnBackfrm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackfrm.Location = new System.Drawing.Point(231, 263);
            this.btnBackfrm.Name = "btnBackfrm";
            this.btnBackfrm.Size = new System.Drawing.Size(75, 23);
            this.btnBackfrm.TabIndex = 2;
            this.btnBackfrm.Text = "Back";
            this.btnBackfrm.UseVisualStyleBackColor = false;
            this.btnBackfrm.Click += new System.EventHandler(this.btnBackfrm_Click);
            // 
            // btnExitFrm
            // 
            this.btnExitFrm.BackColor = System.Drawing.Color.Red;
            this.btnExitFrm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExitFrm.Location = new System.Drawing.Point(351, 263);
            this.btnExitFrm.Name = "btnExitFrm";
            this.btnExitFrm.Size = new System.Drawing.Size(75, 23);
            this.btnExitFrm.TabIndex = 3;
            this.btnExitFrm.Text = "Exit";
            this.btnExitFrm.UseVisualStyleBackColor = false;
            this.btnExitFrm.Click += new System.EventHandler(this.btnExitFrm_Click);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.BackColor = System.Drawing.Color.Gold;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(91, 16);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(68, 15);
            this.lblID.TabIndex = 4;
            this.lblID.Text = "Patient Id";
            // 
            // lblPName
            // 
            this.lblPName.AutoSize = true;
            this.lblPName.BackColor = System.Drawing.Color.Gold;
            this.lblPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPName.Location = new System.Drawing.Point(91, 96);
            this.lblPName.Name = "lblPName";
            this.lblPName.Size = new System.Drawing.Size(94, 15);
            this.lblPName.TabIndex = 5;
            this.lblPName.Text = "Patient Name";
            // 
            // lblSttmnt
            // 
            this.lblSttmnt.AutoSize = true;
            this.lblSttmnt.BackColor = System.Drawing.Color.Gold;
            this.lblSttmnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSttmnt.Location = new System.Drawing.Point(91, 168);
            this.lblSttmnt.Name = "lblSttmnt";
            this.lblSttmnt.Size = new System.Drawing.Size(119, 15);
            this.lblSttmnt.TabIndex = 7;
            this.lblSttmnt.Text = "Report Statement";
            // 
            // txtID
            // 
            this.txtID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(266, 13);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(150, 21);
            this.txtID.TabIndex = 8;
            // 
            // txtPName
            // 
            this.txtPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPName.Location = new System.Drawing.Point(266, 93);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(150, 21);
            this.txtPName.TabIndex = 9;
            // 
            // txtStmt
            // 
            this.txtStmt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStmt.Location = new System.Drawing.Point(266, 165);
            this.txtStmt.Name = "txtStmt";
            this.txtStmt.Size = new System.Drawing.Size(150, 21);
            this.txtStmt.TabIndex = 11;
            // 
            // Report_Details
            // 
            this.BackgroundImage = global::Covid_19DatabaseManagementSystem.Properties.Resources.aed55c1f1f133964094cb07e4f391b7e1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(442, 300);
            this.Controls.Add(this.txtStmt);
            this.Controls.Add(this.txtPName);
            this.Controls.Add(this.txtID);
            this.Controls.Add(this.lblSttmnt);
            this.Controls.Add(this.lblPName);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.btnExitFrm);
            this.Controls.Add(this.btnBackfrm);
            this.Controls.Add(this.btnclearRec);
            this.Controls.Add(this.btnSaveRec);
            this.Name = "Report_Details";
            this.Text = "Report Details";
            this.Load += new System.EventHandler(this.Report_Details_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblPID;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtPID;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lblStmt;
        private System.Windows.Forms.Button btnSaveRec;
        private System.Windows.Forms.Button btnclearRec;
        private System.Windows.Forms.Button btnBackfrm;
        private System.Windows.Forms.Button btnExitFrm;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblPName;
        private System.Windows.Forms.Label lblSttmnt;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.TextBox txtStmt;
    }
}