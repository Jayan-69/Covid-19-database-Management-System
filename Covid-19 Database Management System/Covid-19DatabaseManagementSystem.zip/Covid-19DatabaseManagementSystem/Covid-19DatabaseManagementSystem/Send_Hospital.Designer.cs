﻿namespace Covid_19DatabaseManagementSystem
{
    partial class Send_Hospital
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblID = new System.Windows.Forms.Label();
            this.lblPName = new System.Windows.Forms.Label();
            this.lblHsptl = new System.Windows.Forms.Label();
            this.lblWdNo = new System.Windows.Forms.Label();
            this.lblBdNo = new System.Windows.Forms.Label();
            this.txtPID = new System.Windows.Forms.TextBox();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.txtHsptl = new System.Windows.Forms.TextBox();
            this.txtWdNo = new System.Windows.Forms.TextBox();
            this.txtBdNo = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnDVG = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Blue;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(50, 424);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Blue;
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(259, 424);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Blue;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(442, 424);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(608, 424);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.BackColor = System.Drawing.Color.Gold;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.Location = new System.Drawing.Point(71, 67);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(70, 15);
            this.lblID.TabIndex = 4;
            this.lblID.Text = "Patient ID";
            // 
            // lblPName
            // 
            this.lblPName.AutoSize = true;
            this.lblPName.BackColor = System.Drawing.Color.Gold;
            this.lblPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPName.Location = new System.Drawing.Point(71, 142);
            this.lblPName.Name = "lblPName";
            this.lblPName.Size = new System.Drawing.Size(94, 15);
            this.lblPName.TabIndex = 5;
            this.lblPName.Text = "Patient Name";
            // 
            // lblHsptl
            // 
            this.lblHsptl.AutoSize = true;
            this.lblHsptl.BackColor = System.Drawing.Color.Gold;
            this.lblHsptl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHsptl.Location = new System.Drawing.Point(71, 217);
            this.lblHsptl.Name = "lblHsptl";
            this.lblHsptl.Size = new System.Drawing.Size(60, 15);
            this.lblHsptl.TabIndex = 6;
            this.lblHsptl.Text = "Hospital";
            // 
            // lblWdNo
            // 
            this.lblWdNo.AutoSize = true;
            this.lblWdNo.BackColor = System.Drawing.Color.Gold;
            this.lblWdNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWdNo.Location = new System.Drawing.Point(71, 290);
            this.lblWdNo.Name = "lblWdNo";
            this.lblWdNo.Size = new System.Drawing.Size(66, 15);
            this.lblWdNo.TabIndex = 7;
            this.lblWdNo.Text = "Ward No ";
            // 
            // lblBdNo
            // 
            this.lblBdNo.AutoSize = true;
            this.lblBdNo.BackColor = System.Drawing.Color.Gold;
            this.lblBdNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBdNo.Location = new System.Drawing.Point(71, 360);
            this.lblBdNo.Name = "lblBdNo";
            this.lblBdNo.Size = new System.Drawing.Size(54, 15);
            this.lblBdNo.TabIndex = 8;
            this.lblBdNo.Text = "Bed No";
            // 
            // txtPID
            // 
            this.txtPID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPID.Location = new System.Drawing.Point(227, 64);
            this.txtPID.Name = "txtPID";
            this.txtPID.Size = new System.Drawing.Size(175, 21);
            this.txtPID.TabIndex = 9;
            // 
            // txtPName
            // 
            this.txtPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPName.Location = new System.Drawing.Point(227, 139);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(175, 21);
            this.txtPName.TabIndex = 10;
            // 
            // txtHsptl
            // 
            this.txtHsptl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHsptl.Location = new System.Drawing.Point(227, 214);
            this.txtHsptl.Name = "txtHsptl";
            this.txtHsptl.Size = new System.Drawing.Size(175, 21);
            this.txtHsptl.TabIndex = 11;
            // 
            // txtWdNo
            // 
            this.txtWdNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWdNo.Location = new System.Drawing.Point(227, 287);
            this.txtWdNo.Name = "txtWdNo";
            this.txtWdNo.Size = new System.Drawing.Size(175, 21);
            this.txtWdNo.TabIndex = 12;
            // 
            // txtBdNo
            // 
            this.txtBdNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBdNo.Location = new System.Drawing.Point(227, 353);
            this.txtBdNo.Name = "txtBdNo";
            this.txtBdNo.Size = new System.Drawing.Size(175, 21);
            this.txtBdNo.TabIndex = 13;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(442, 64);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(293, 171);
            this.dataGridView1.TabIndex = 14;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnDVG
            // 
            this.btnDVG.BackColor = System.Drawing.Color.Lime;
            this.btnDVG.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDVG.Location = new System.Drawing.Point(522, 282);
            this.btnDVG.Name = "btnDVG";
            this.btnDVG.Size = new System.Drawing.Size(132, 23);
            this.btnDVG.TabIndex = 15;
            this.btnDVG.Text = "Data Grid View";
            this.btnDVG.UseVisualStyleBackColor = false;
            this.btnDVG.Click += new System.EventHandler(this.btnDVG_Click);
            // 
            // Send_Hospital
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Covid_19DatabaseManagementSystem.Properties.Resources.aed55c1f1f133964094cb07e4f391b7e1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(761, 459);
            this.Controls.Add(this.btnDVG);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtBdNo);
            this.Controls.Add(this.txtWdNo);
            this.Controls.Add(this.txtHsptl);
            this.Controls.Add(this.txtPName);
            this.Controls.Add(this.txtPID);
            this.Controls.Add(this.lblBdNo);
            this.Controls.Add(this.lblWdNo);
            this.Controls.Add(this.lblHsptl);
            this.Controls.Add(this.lblPName);
            this.Controls.Add(this.lblID);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnAdd);
            this.Name = "Send_Hospital";
            this.Text = "Hospital Registration";
            this.Load += new System.EventHandler(this.Send_Hospital_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label lblPName;
        private System.Windows.Forms.Label lblHsptl;
        private System.Windows.Forms.Label lblWdNo;
        private System.Windows.Forms.Label lblBdNo;
        private System.Windows.Forms.TextBox txtPID;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.TextBox txtHsptl;
        private System.Windows.Forms.TextBox txtWdNo;
        private System.Windows.Forms.TextBox txtBdNo;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnDVG;
    }
}