﻿namespace Covid_19DatabaseManagementSystem
{
    partial class Pcr_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRptdetls = new System.Windows.Forms.Button();
            this.btnExist = new System.Windows.Forms.Button();
            this.btnHos = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRptdetls
            // 
            this.btnRptdetls.BackColor = System.Drawing.Color.Lime;
            this.btnRptdetls.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRptdetls.Location = new System.Drawing.Point(12, 96);
            this.btnRptdetls.Name = "btnRptdetls";
            this.btnRptdetls.Size = new System.Drawing.Size(151, 122);
            this.btnRptdetls.TabIndex = 0;
            this.btnRptdetls.Text = "Add Report Details";
            this.btnRptdetls.UseVisualStyleBackColor = false;
            this.btnRptdetls.Click += new System.EventHandler(this.btnRptdetls_Click);
            // 
            // btnExist
            // 
            this.btnExist.BackColor = System.Drawing.Color.Lime;
            this.btnExist.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExist.Location = new System.Drawing.Point(196, 96);
            this.btnExist.Name = "btnExist";
            this.btnExist.Size = new System.Drawing.Size(151, 122);
            this.btnExist.TabIndex = 1;
            this.btnExist.Text = "Existing Patients";
            this.btnExist.UseVisualStyleBackColor = false;
            this.btnExist.Click += new System.EventHandler(this.btnExist_Click);
            // 
            // btnHos
            // 
            this.btnHos.BackColor = System.Drawing.Color.Lime;
            this.btnHos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHos.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnHos.Location = new System.Drawing.Point(379, 96);
            this.btnHos.Name = "btnHos";
            this.btnHos.Size = new System.Drawing.Size(151, 122);
            this.btnHos.TabIndex = 2;
            this.btnHos.Text = "Hospital Registration For Positive Patients";
            this.btnHos.UseVisualStyleBackColor = false;
            this.btnHos.Click += new System.EventHandler(this.btnHos_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.Blue;
            this.btnBack.Location = new System.Drawing.Point(138, 327);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 3;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.Red;
            this.btnExit.Location = new System.Drawing.Point(325, 327);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Pcr_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Covid_19DatabaseManagementSystem.Properties.Resources.aed55c1f1f133964094cb07e4f391b7e2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(542, 377);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnHos);
            this.Controls.Add(this.btnExist);
            this.Controls.Add(this.btnRptdetls);
            this.Name = "Pcr_Info";
            this.Text = "PCR Informations";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRptdetls;
        private System.Windows.Forms.Button btnExist;
        private System.Windows.Forms.Button btnHos;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnExit;
    }
}